# Midpoint Visuals

Modern, smooth, lightweight visual client for **Fabric 1.21.4 / Java 21**.
Author: **Midpoint**.

This repo is a working starter implementation of the full architecture:
Render Engine, Animation Engine, HUD Engine, ClickGUI, config persistence
and a particle engine — plus a GitHub Actions workflow that builds the jar
automatically.

## What's included

- **Render Engine**: `ColorUtil`, `RenderUtil`, `RoundedRenderer`,
  `GradientRenderer`, `ShadowRenderer`, `GlowRenderer`, `BlurRenderer`,
  `StencilRenderer`, `TextRenderer`.
- **Animation Engine**: `Easing` (Linear, Sine, Quad, Cubic, Expo, Back,
  Elastic, Bounce) + `AnimatedValue` for smooth interpolated values.
- **HUD Engine**: `HudManager`, `HudElement`, drag support, JSON-persisted
  positions. Includes Watermark, FPS, Coordinates and Keystrokes as
  reference elements — add more by extending `HudElement`.
- **Module system**: `Module`, `ModuleCategory`, `ModuleManager` with
  smooth enable/disable fading built in.
- **ClickGUI**: sidebar categories + module list, toggle switches, rounded
  panels, soft shadow, brand-blue header, spring-style open animation.
- **Particle Engine**: lightweight particle system + a `Hit Effects`
  module that spawns a cosmetic burst on hit.
- **Config**: single JSON file at `.minecraft/config/midpoint-visuals.json`
  storing module states and HUD positions.

## What's intentionally NOT included

Wallhack-style ESP that reveals players, mobs, chests or spawners through
blocks (X-ray-type features) is not implemented here. Those are combat/
survival cheats that give an unfair advantage on multiplayer servers, and
I won't build that regardless of framing. Everything else on your feature
list (Tracers as a purely cosmetic line, China Hat, Target rings, item
physics, nametag styling, trail/particle effects, etc.) can be built on top
of the engines already in this repo using the exact same patterns as
`HitEffectsModule` / `WatermarkElement` — happy to keep extending it with
you module by module.

## Building locally

You need JDK 21 installed.

```bash
git clone <your-repo-url>
cd midpoint-visuals
gradle wrapper --gradle-version 8.10   # only needed once, if gradlew isn't present yet
./gradlew build
```

The built jar will appear in `build/libs/`.

> This project was written without access to the real Fabric/Minecraft
> Maven repositories (sandboxed environment), so it was **not**
> test-compiled against the actual Yarn mappings for 1.21.4. Open it in
> IntelliJ IDEA with the Fabric/Gradle plugins, let Gradle sync, and fix
> any small method/import renames the IDE flags (Minecraft's internal API
> shifts slightly between versions) — the architecture and logic will not
> need to change, only occasional method names.

## Building on GitHub Actions

Just push to `main` or open a PR — `.github/workflows/build.yml` runs
automatically, provisions Gradle 8.10 + JDK 21, generates the wrapper,
builds the mod and uploads the resulting jar as a workflow artifact. Push
a tag like `v1.0.0` and it will also attach the jar to a GitHub Release.

## Adding a new module

```java
public final class MyModule extends Module {
    public MyModule() {
        super("My Module", ModuleCategory.VISUAL);
    }

    @Override
    protected void onEnable() { /* ... */ }

    @Override
    protected void onDisable() { /* ... */ }

    @Override
    public void tick() { /* ... */ }
}
```

Then register it in `ModuleManager`'s constructor. It will automatically
show up in the ClickGUI under its category and persist its state via
`ConfigManager`.

## Adding a new HUD element

```java
public final class MyHud extends HudElement {
    public MyHud() { super("My Hud", 6, 120); }

    @Override
    protected void renderContent(DrawContext context, float deltaTime) {
        // draw using RoundedRenderer / TextRenderer / etc.
    }
}
```

Register it in `HudManager`'s constructor.
