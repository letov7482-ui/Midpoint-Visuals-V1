package com.midpoint.visuals.hud.elements;

import com.midpoint.visuals.hud.HudElement;
import com.midpoint.visuals.render.ColorUtil;
import com.midpoint.visuals.render.RoundedRenderer;
import com.midpoint.visuals.render.TextRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public final class FpsElement extends HudElement {

    public FpsElement() {
        super("FPS", 6, 46);
        this.width = 60;
        this.height = 16;
    }

    @Override
    protected void renderContent(DrawContext context, float deltaTime) {
        float alpha = fade.get();
        int fps = MinecraftClient.getInstance().getCurrentFps();

        RoundedRenderer.drawRoundedRect(context, x, y, width, height, 5,
                ColorUtil.withAlpha(ColorUtil.PANEL_GRAY, (int) (180 * alpha)));
        TextRenderer.draw(context, fps + " fps", x + 6, y + 4,
                ColorUtil.rgba(255, 255, 255, (int) (255 * alpha)), false);
    }
}
