package com.midpoint.visuals.client;

import com.midpoint.visuals.config.ConfigManager;
import com.midpoint.visuals.hud.HudManager;
import com.midpoint.visuals.module.ModuleManager;
import com.midpoint.visuals.particle.ParticleEngine;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * Entry point for Midpoint Visuals.
 * <p>
 * This class only wires the different engines together (Config, Modules,
 * HUD, Particles). Actual logic lives inside its own manager class so this
 * file stays small and readable.
 */
public final class MidpointVisualsClient implements ClientModInitializer {

    public static final String MOD_ID = "midpoint-visuals";
    public static final String MOD_NAME = "Midpoint Visuals";
    public static final String AUTHOR = "Midpoint";

    private static MidpointVisualsClient instance;

    private ConfigManager configManager;
    private ModuleManager moduleManager;
    private HudManager hudManager;
    private ParticleEngine particleEngine;

    private KeyBinding openClickGuiKey;

    @Override
    public void onInitializeClient() {
        instance = this;

        configManager = new ConfigManager();
        moduleManager = new ModuleManager();
        hudManager = new HudManager(configManager);
        particleEngine = new ParticleEngine();

        configManager.load(moduleManager, hudManager);

        registerKeyBindings();
        registerEvents();
    }

    private void registerKeyBindings() {
        openClickGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.midpoint-visuals.clickgui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.midpoint-visuals.general"
        ));
    }

    private void registerEvents() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            moduleManager.tickAll();
            particleEngine.tick();

            while (openClickGuiKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new com.midpoint.visuals.gui.ClickGuiScreen(moduleManager));
                }
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.options.hudHidden) return;

            float deltaTime = tickCounter.getTickDelta(true);
            hudManager.render(drawContext, deltaTime);
            particleEngine.render(drawContext, deltaTime);
        });
    }

    public static MidpointVisualsClient getInstance() {
        return instance;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public ModuleManager getModuleManager() {
        return moduleManager;
    }

    public HudManager getHudManager() {
        return hudManager;
    }

    public ParticleEngine getParticleEngine() {
        return particleEngine;
    }
}
