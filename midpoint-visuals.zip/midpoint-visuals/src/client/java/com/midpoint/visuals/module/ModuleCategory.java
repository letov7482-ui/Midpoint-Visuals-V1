package com.midpoint.visuals.module;

public enum ModuleCategory {
    VISUAL,
    HUD,
    RENDER,
    MISC
}
