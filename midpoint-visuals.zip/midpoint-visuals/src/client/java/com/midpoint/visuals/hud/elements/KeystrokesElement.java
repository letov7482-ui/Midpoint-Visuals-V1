package com.midpoint.visuals.hud.elements;

import com.midpoint.visuals.hud.HudElement;
import com.midpoint.visuals.render.ColorUtil;
import com.midpoint.visuals.render.RoundedRenderer;
import com.midpoint.visuals.render.TextRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/** Classic KeyStrokes HUD: W/A/S/D keys light up in brand-blue while held. */
public final class KeystrokesElement extends HudElement {

    private static final int KEY_SIZE = 18;

    public KeystrokesElement() {
        super("Keystrokes", 6, 90);
        this.width = KEY_SIZE * 3 + 4;
        this.height = KEY_SIZE * 2 + 2;
    }

    @Override
    protected void renderContent(DrawContext context, float deltaTime) {
        float alpha = fade.get();
        long handle = MinecraftClient.getInstance().getWindow().getHandle();

        drawKey(context, "W", x + KEY_SIZE + 2, y, isDown(handle, GLFW.GLFW_KEY_W), alpha);
        drawKey(context, "A", x, y + KEY_SIZE + 2, isDown(handle, GLFW.GLFW_KEY_A), alpha);
        drawKey(context, "S", x + KEY_SIZE + 2, y + KEY_SIZE + 2, isDown(handle, GLFW.GLFW_KEY_S), alpha);
        drawKey(context, "D", x + (KEY_SIZE + 2) * 2, y + KEY_SIZE + 2, isDown(handle, GLFW.GLFW_KEY_D), alpha);
    }

    private boolean isDown(long handle, int key) {
        return InputUtil.isKeyPressed(handle, key);
    }

    private void drawKey(DrawContext context, String label, float kx, float ky, boolean active, float alpha) {
        int bg = active
                ? ColorUtil.withAlpha(ColorUtil.BRAND_BLUE, (int) (220 * alpha))
                : ColorUtil.withAlpha(ColorUtil.PANEL_GRAY, (int) (180 * alpha));

        RoundedRenderer.drawRoundedRect(context, kx, ky, KEY_SIZE, KEY_SIZE, 4, bg);
        TextRenderer.draw(context, label, kx + KEY_SIZE / 2f - 3, ky + KEY_SIZE / 2f - 4,
                ColorUtil.rgba(255, 255, 255, (int) (255 * alpha)), false);
    }
}
