package com.midpoint.visuals.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.midpoint.visuals.hud.HudElement;
import com.midpoint.visuals.hud.HudManager;
import com.midpoint.visuals.module.Module;
import com.midpoint.visuals.module.ModuleManager;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/**
 * Persists module enabled-states and HUD element positions to a single JSON
 * file under {@code .minecraft/config/midpoint-visuals.json}. Loss-less:
 * unknown/missing entries are simply skipped rather than crashing.
 */
public final class ConfigManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private final Path configPath = FabricLoader.getInstance()
            .getConfigDir()
            .resolve("midpoint-visuals.json");

    public void load(ModuleManager moduleManager, HudManager hudManager) {
        if (!Files.exists(configPath)) {
            save(moduleManager, hudManager);
            return;
        }

        try (Reader reader = Files.newBufferedReader(configPath, StandardCharsets.UTF_8)) {
            ConfigData data = GSON.fromJson(reader, ConfigData.class);
            if (data == null) return;

            for (Module module : moduleManager.getModules()) {
                Boolean state = data.modules.get(module.getName());
                if (state != null) {
                    module.setEnabled(state, true);
                }
            }

            for (HudElement element : hudManager.getElements()) {
                float[] pos = data.hudPositions.get(element.getName());
                if (pos != null && pos.length == 2) {
                    element.setPosition(pos[0], pos[1]);
                }
            }
        } catch (IOException e) {
            System.err.println("[Midpoint Visuals] Failed to load config: " + e.getMessage());
        }
    }

    public void save(ModuleManager moduleManager, HudManager hudManager) {
        ConfigData data = new ConfigData();

        for (Module module : moduleManager.getModules()) {
            data.modules.put(module.getName(), module.isEnabled());
        }

        for (HudElement element : hudManager.getElements()) {
            data.hudPositions.put(element.getName(), new float[]{element.getX(), element.getY()});
        }

        try {
            Files.createDirectories(configPath.getParent());
            try (Writer writer = Files.newBufferedWriter(configPath, StandardCharsets.UTF_8)) {
                GSON.toJson(data, writer);
            }
        } catch (IOException e) {
            System.err.println("[Midpoint Visuals] Failed to save config: " + e.getMessage());
        }
    }

    private static final class ConfigData {
        Map<String, Boolean> modules = new HashMap<>();
        Map<String, float[]> hudPositions = new HashMap<>();
    }
}
