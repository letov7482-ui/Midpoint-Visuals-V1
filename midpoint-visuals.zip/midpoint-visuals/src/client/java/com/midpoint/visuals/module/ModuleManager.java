package com.midpoint.visuals.module;

import com.midpoint.visuals.module.modules.FullbrightModule;
import com.midpoint.visuals.module.modules.HitEffectsModule;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Holds every registered {@link Module}. New visual modules are added by
 * instantiating them here - the ClickGUI, config saving and tick loop all
 * work automatically off this single registry, no other file needs touching.
 */
public final class ModuleManager {

    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        register(new FullbrightModule());
        register(new HitEffectsModule());
        // Add new modules here, e.g.:
        // register(new TracersModule());
        // register(new ChinaHatModule());
    }

    private void register(Module module) {
        modules.add(module);
    }

    public void tickAll() {
        for (Module module : modules) {
            if (module.isEnabled() || module.getFade() > 0f) {
                module.tick();
            }
        }
    }

    public List<Module> getModules() {
        return modules;
    }

    public List<Module> getModulesByCategory(ModuleCategory category) {
        return modules.stream().filter(m -> m.getCategory() == category).toList();
    }

    public Optional<Module> getByName(String name) {
        return modules.stream().filter(m -> m.getName().equalsIgnoreCase(name)).findFirst();
    }
}
