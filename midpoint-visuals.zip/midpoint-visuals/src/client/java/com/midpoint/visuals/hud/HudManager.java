package com.midpoint.visuals.hud;

import com.midpoint.visuals.config.ConfigManager;
import com.midpoint.visuals.hud.elements.CoordsElement;
import com.midpoint.visuals.hud.elements.FpsElement;
import com.midpoint.visuals.hud.elements.KeystrokesElement;
import com.midpoint.visuals.hud.elements.WatermarkElement;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/**
 * Owns every {@link HudElement}, renders them each frame and (while the
 * in-game chat/HUD-edit screen is open) allows dragging them around. Drag
 * offsets are handed back to {@link ConfigManager} so positions persist.
 */
public final class HudManager {

    private final List<HudElement> elements = new ArrayList<>();
    private HudElement dragging;
    private float dragOffsetX, dragOffsetY;

    public HudManager(ConfigManager configManager) {
        elements.add(new WatermarkElement());
        elements.add(new FpsElement());
        elements.add(new CoordsElement());
        elements.add(new KeystrokesElement());
        // Add more elements here: PingElement, ArmorHudElement, ArrayListElement, etc.
    }

    public void render(DrawContext context, float deltaTime) {
        for (HudElement element : elements) {
            element.render(context, deltaTime);
        }
    }

    public List<HudElement> getElements() {
        return elements;
    }

    public void startDrag(double mouseX, double mouseY) {
        for (HudElement element : elements) {
            if (element.isHovered(mouseX, mouseY)) {
                dragging = element;
                dragOffsetX = (float) (mouseX - element.getX());
                dragOffsetY = (float) (mouseY - element.getY());
                return;
            }
        }
    }

    public void updateDrag(double mouseX, double mouseY) {
        if (dragging == null) return;
        dragging.setPosition((float) (mouseX - dragOffsetX), (float) (mouseY - dragOffsetY));
    }

    public void stopDrag() {
        dragging = null;
    }

    public boolean isDragging() {
        return dragging != null;
    }
}
