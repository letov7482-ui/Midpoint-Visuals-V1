package com.midpoint.visuals.hud.elements;

import com.midpoint.visuals.hud.HudElement;
import com.midpoint.visuals.render.ColorUtil;
import com.midpoint.visuals.render.RoundedRenderer;
import com.midpoint.visuals.render.TextRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;

public final class CoordsElement extends HudElement {

    public CoordsElement() {
        super("Coordinates", 6, 68);
        this.width = 110;
        this.height = 16;
    }

    @Override
    protected void renderContent(DrawContext context, float deltaTime) {
        Entity camera = MinecraftClient.getInstance().getCameraEntity();
        if (camera == null) return;

        float alpha = fade.get();
        String text = String.format("%.0f, %.0f, %.0f", camera.getX(), camera.getY(), camera.getZ());

        RoundedRenderer.drawRoundedRect(context, x, y, width, height, 5,
                ColorUtil.withAlpha(ColorUtil.PANEL_GRAY, (int) (180 * alpha)));
        TextRenderer.draw(context, text, x + 6, y + 4,
                ColorUtil.rgba(255, 255, 255, (int) (255 * alpha)), false);
    }
}
