package com.midpoint.visuals.render;

import net.minecraft.client.gui.DrawContext;

/**
 * Clips rendering to a rectangular region using the vanilla scissor stack.
 * Used by the ClickGUI module list and any scrollable panel so content
 * doesn't overflow its container while animating.
 */
public final class StencilRenderer {

    private StencilRenderer() {
    }

    public static void withClip(DrawContext context, int x, int y, int width, int height, Runnable block) {
        context.enableScissor(x, y, x + width, y + height);
        try {
            block.run();
        } finally {
            context.disableScissor();
        }
    }
}
