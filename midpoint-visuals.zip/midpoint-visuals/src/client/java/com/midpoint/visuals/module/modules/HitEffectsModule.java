package com.midpoint.visuals.module.modules;

import com.midpoint.visuals.client.MidpointVisualsClient;
import com.midpoint.visuals.module.Module;
import com.midpoint.visuals.module.ModuleCategory;
import com.midpoint.visuals.particle.HitEffectType;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.entity.Entity;
import net.minecraft.util.ActionResult;

/**
 * Spawns a burst of decorative particles (stars, sparks, energy, ...) at an
 * entity's position whenever the local player hits it. Purely cosmetic -
 * doesn't reveal any information the vanilla client wouldn't already show.
 */
public final class HitEffectsModule extends Module {

    private HitEffectType effectType = HitEffectType.BLUE_ENERGY;

    public HitEffectsModule() {
        super("Hit Effects", ModuleCategory.VISUAL);
        AttackEntityCallback.EVENT.register(this::onAttack);
    }

    private ActionResult onAttack(net.minecraft.entity.player.PlayerEntity player, net.minecraft.world.World world, net.minecraft.util.Hand hand, Entity target, net.minecraft.util.hit.EntityHitResult hitResult) {
        if (!isEnabled() || !world.isClient) {
            return ActionResult.PASS;
        }

        MidpointVisualsClient.getInstance().getParticleEngine().spawnHitEffect(
                target.getX(), target.getY() + target.getHeight() / 2.0, target.getZ(),
                effectType
        );

        return ActionResult.PASS;
    }

    public HitEffectType getEffectType() {
        return effectType;
    }

    public void setEffectType(HitEffectType effectType) {
        this.effectType = effectType;
    }
}
