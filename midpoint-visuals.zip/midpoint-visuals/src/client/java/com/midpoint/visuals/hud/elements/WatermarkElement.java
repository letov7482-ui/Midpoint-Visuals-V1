package com.midpoint.visuals.hud.elements;

import com.midpoint.visuals.client.MidpointVisualsClient;
import com.midpoint.visuals.hud.HudElement;
import com.midpoint.visuals.render.ColorUtil;
import com.midpoint.visuals.render.GradientRenderer;
import com.midpoint.visuals.render.RoundedRenderer;
import com.midpoint.visuals.render.ShadowRenderer;
import com.midpoint.visuals.render.TextRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * The client's signature watermark:
 * <pre>
 *  Midpoint Visuals
 *  245 FPS • 28 ms
 * </pre>
 * Dark translucent panel, soft shadow and a bright blue accent bar on top.
 */
public final class WatermarkElement extends HudElement {

    public WatermarkElement() {
        super("Watermark", 6, 6);
        this.width = 132;
        this.height = 34;
    }

    @Override
    protected void renderContent(DrawContext context, float deltaTime) {
        float alpha = fade.get();
        if (alpha <= 0.01f) return;

        MinecraftClient client = MinecraftClient.getInstance();
        int fps = client.getCurrentFps();
        int ping = 0; // wire this up to the player's PlayerListEntry latency if desired

        int panelAlpha = (int) (190 * alpha);
        int textAlpha = ColorUtil.rgba(255, 255, 255, (int) (255 * alpha));
        int subTextAlpha = ColorUtil.rgba(190, 205, 235, (int) (200 * alpha));

        ShadowRenderer.drawShadow(context, x, y, width, height, 8, 4, (int) (90 * alpha));
        RoundedRenderer.drawRoundedRect(context, x, y, width, height, 8, ColorUtil.withAlpha(ColorUtil.PANEL_BLACK, panelAlpha));
        GradientRenderer.accentBar(context, Math.round(x + 6), Math.round(y), Math.round(width - 12), 2);

        TextRenderer.draw(context, MidpointVisualsClient.MOD_NAME, x + 8, y + 8, textAlpha, false);
        TextRenderer.draw(context, fps + " FPS  \u2022  " + ping + " ms", x + 8, y + 20, subTextAlpha, false);
    }
}
