package com.midpoint.visuals.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.DrawContext;

/**
 * Shared low-level rendering helpers (state pushing/popping, scissoring, etc).
 * Every other *Renderer class in this package builds on top of this one so
 * the actual GL/pipeline calls only exist in a single place.
 */
public final class RenderUtil {

    private RenderUtil() {
    }

    public static void enableBlend() {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
    }

    public static void disableBlend() {
        RenderSystem.disableBlend();
    }

    /** Pushes the matrix stack, runs the render block, then pops it back. Prevents leaked transforms. */
    public static void withMatrix(DrawContext context, Runnable renderBlock) {
        context.getMatrices().push();
        try {
            renderBlock.run();
        } finally {
            context.getMatrices().pop();
        }
    }

    /** Clamps a value between min/max, used constantly across the render engine. */
    public static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    public static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }
}
