package com.midpoint.visuals.gui;

import com.midpoint.visuals.animation.AnimatedValue;
import com.midpoint.visuals.animation.Easing;
import com.midpoint.visuals.module.Module;
import com.midpoint.visuals.module.ModuleCategory;
import com.midpoint.visuals.module.ModuleManager;
import com.midpoint.visuals.render.BlurRenderer;
import com.midpoint.visuals.render.ColorUtil;
import com.midpoint.visuals.render.RoundedRenderer;
import com.midpoint.visuals.render.ShadowRenderer;
import com.midpoint.visuals.render.StencilRenderer;
import com.midpoint.visuals.render.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;

/**
 * Midpoint's ClickGUI: categories on the left, modules of the selected
 * category on the right, everything animated in with a smooth fade + scale.
 * This is a compact starter implementation - sliders/color pickers/search
 * can be layered on top following the same rendering pattern.
 */
public final class ClickGuiScreen extends Screen {

    private final ModuleManager moduleManager;
    private final AnimatedValue openProgress = new AnimatedValue(0f, Easing.BACK_OUT, 350);

    private ModuleCategory selectedCategory = ModuleCategory.VISUAL;

    private static final int PANEL_WIDTH = 320;
    private static final int PANEL_HEIGHT = 220;
    private static final int SIDEBAR_WIDTH = 90;

    public ClickGuiScreen(ModuleManager moduleManager) {
        super(Text.literal("Midpoint Visuals"));
        this.moduleManager = moduleManager;
        openProgress.animateTo(1f);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);

        float progress = openProgress.get();
        int centerX = width / 2;
        int centerY = height / 2;

        float panelW = PANEL_WIDTH * progress;
        float panelH = PANEL_HEIGHT * progress;
        float px = centerX - panelW / 2;
        float py = centerY - panelH / 2;

        ShadowRenderer.drawShadow(context, px, py, panelW, panelH, 10, 6, 120);
        RoundedRenderer.drawRoundedRect(context, px, py, panelW, panelH, 10, ColorUtil.PANEL_BLACK);
        RoundedRenderer.drawRoundedRectTop(context, px, py, panelW, 28, 10, ColorUtil.withAlpha(ColorUtil.BRAND_BLUE, 220));

        TextRenderer.draw(context, "Midpoint Visuals", px + 10, py + 9, ColorUtil.rgba(255, 255, 255, 255), false);

        if (progress > 0.9f) {
            renderSidebar(context, px, py + 28, mouseX, mouseY);
            renderModuleList(context, px + SIDEBAR_WIDTH, py + 28, panelW - SIDEBAR_WIDTH, panelH - 28, mouseX, mouseY);
        }

        super.render(context, mouseX, mouseY, delta);
    }

    private void renderSidebar(DrawContext context, float x, float y, int mouseX, int mouseY) {
        ModuleCategory[] categories = ModuleCategory.values();
        float entryHeight = 26;

        for (int i = 0; i < categories.length; i++) {
            ModuleCategory category = categories[i];
            float ey = y + i * entryHeight;
            boolean hovered = mouseX >= x && mouseX <= x + SIDEBAR_WIDTH && mouseY >= ey && mouseY <= ey + entryHeight;
            boolean selected = category == selectedCategory;

            if (selected) {
                RoundedRenderer.drawRoundedRect(context, x + 4, ey + 2, SIDEBAR_WIDTH - 8, entryHeight - 4, 6,
                        ColorUtil.withAlpha(ColorUtil.BRAND_BLUE, 200));
            } else if (hovered) {
                RoundedRenderer.drawRoundedRect(context, x + 4, ey + 2, SIDEBAR_WIDTH - 8, entryHeight - 4, 6,
                        ColorUtil.withAlpha(ColorUtil.PANEL_GRAY, 160));
            }

            TextRenderer.draw(context, category.name(), x + 12, ey + 9, ColorUtil.rgba(255, 255, 255, 255), false);
        }
    }

    private void renderModuleList(DrawContext context, float x, float y, float w, float h, int mouseX, int mouseY) {
        StencilRenderer.withClip(context, Math.round(x), Math.round(y), Math.round(w), Math.round(h), () -> {
            List<Module> modules = moduleManager.getModulesByCategory(selectedCategory);
            float entryHeight = 24;

            for (int i = 0; i < modules.size(); i++) {
                Module module = modules.get(i);
                float ey = y + 6 + i * (entryHeight + 4);

                boolean hovered = mouseX >= x + 6 && mouseX <= x + w - 6 && mouseY >= ey && mouseY <= ey + entryHeight;
                int bg = module.isEnabled()
                        ? ColorUtil.withAlpha(ColorUtil.BRAND_BLUE, 90)
                        : ColorUtil.withAlpha(ColorUtil.PANEL_GRAY, hovered ? 200 : 150);

                RoundedRenderer.drawRoundedRect(context, x + 6, ey, w - 12, entryHeight, 6, bg);
                TextRenderer.draw(context, module.getName(), x + 14, ey + 8, ColorUtil.rgba(255, 255, 255, 255), false);

                drawToggle(context, x + w - 40, ey + 5, module.isEnabled());
            }
        });
    }

    private void drawToggle(DrawContext context, float x, float y, boolean on) {
        int track = on ? ColorUtil.withAlpha(ColorUtil.BRAND_BLUE, 255) : ColorUtil.withAlpha(ColorUtil.PANEL_GRAY, 255);
        RoundedRenderer.drawRoundedRect(context, x, y, 26, 14, 7, track);

        float knobX = on ? x + 26 - 12 : x + 2;
        RoundedRenderer.drawRoundedRect(context, knobX, y + 2, 10, 10, 5, ColorUtil.rgba(255, 255, 255, 255));
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        float px = width / 2f - PANEL_WIDTH / 2f;
        float py = height / 2f - PANEL_HEIGHT / 2f;

        // Sidebar category selection
        ModuleCategory[] categories = ModuleCategory.values();
        float sy = py + 28;
        for (int i = 0; i < categories.length; i++) {
            float ey = sy + i * 26;
            if (mouseX >= px && mouseX <= px + SIDEBAR_WIDTH && mouseY >= ey && mouseY <= ey + 26) {
                selectedCategory = categories[i];
                return true;
            }
        }

        // Module toggles
        List<Module> modules = moduleManager.getModulesByCategory(selectedCategory);
        float listX = px + SIDEBAR_WIDTH;
        float listY = py + 28;
        float entryHeight = 24;
        for (int i = 0; i < modules.size(); i++) {
            float ey = listY + 6 + i * (entryHeight + 4);
            if (mouseX >= listX + 6 && mouseX <= listX + PANEL_WIDTH - SIDEBAR_WIDTH - 6 && mouseY >= ey && mouseY <= ey + entryHeight) {
                modules.get(i).toggle();
                return true;
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
