package com.midpoint.visuals.render;

import net.minecraft.client.gui.DrawContext;

/**
 * Lightweight "fake blur" backdrop: a semi-transparent dark panel instead of
 * a real multi-pass gaussian blur shader. This keeps GUI Blur / Inventory
 * Blur / Scoreboard Blur cheap enough to run smoothly on Android and Pojav.
 * <p>
 * A real shader-based blur can be swapped in later by replacing the body of
 * {@link #drawBackdrop} only - every caller in the codebase goes through
 * this single method.
 */
public final class BlurRenderer {

    private BlurRenderer() {
    }

    public static void drawBackdrop(DrawContext context, int x, int y, int width, int height, int darkness) {
        context.fill(x, y, x + width, y + height, ColorUtil.rgba(0, 0, 0, darkness));
    }

    public static void drawPanelBackdrop(DrawContext context, float x, float y, float width, float height, float radius) {
        RoundedRenderer.drawRoundedRect(context, x, y, width, height, radius, ColorUtil.PANEL_BLACK);
    }
}
