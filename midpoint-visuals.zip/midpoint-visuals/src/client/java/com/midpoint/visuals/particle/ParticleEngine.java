package com.midpoint.visuals.particle;

import com.midpoint.visuals.render.ColorUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A small, self-contained particle system. Kept deliberately simple
 * (no allocations per frame, capped particle count) so it stays cheap on
 * Android/Pojav as required by the project's performance goals.
 */
public final class ParticleEngine {

    private static final int MAX_PARTICLES = 400;

    private final List<Particle> particles = new ArrayList<>();

    public void spawnHitEffect(double x, double y, double z, HitEffectType type) {
        int count = 10;
        for (int i = 0; i < count && particles.size() < MAX_PARTICLES; i++) {
            float angle = (float) (Math.random() * Math.PI * 2);
            float speed = 0.05f + (float) Math.random() * 0.08f;

            float velX = (float) Math.cos(angle) * speed;
            float velZ = (float) Math.sin(angle) * speed;
            float velY = 0.05f + (float) Math.random() * 0.08f;

            float size = 0.15f + (float) Math.random() * 0.15f;
            int lifeTicks = 14 + (int) (Math.random() * 8);

            particles.add(new Particle(x, y, z, velX, velY, velZ, size, type.color, lifeTicks));
        }
    }

    public void tick() {
        Iterator<Particle> it = particles.iterator();
        while (it.hasNext()) {
            Particle p = it.next();

            p.x += p.velX;
            p.y += p.velY;
            p.z += p.velZ;

            p.velY -= 0.01f; // gravity
            p.velX *= 0.96f;
            p.velZ *= 0.96f;

            p.rotation += p.rotationSpeed;
            p.lifeTicks++;

            if (p.isDead()) {
                it.remove();
            }
        }
    }

    /**
     * Renders every particle as a small camera-facing quad drawn in a single
     * pass. Kept here (rather than injected via mixin into WorldRenderer) to
     * keep this starter project mixin-free and easy to build.
     */
    public void render(DrawContext context, float tickDelta) {
        if (particles.isEmpty()) return;

        MinecraftClient client = MinecraftClient.getInstance();
        Camera camera = client.gameRenderer.getCamera();
        if (!camera.isReady()) return;

        Vec3d camPos = camera.getPos();

        // NOTE: for real world-space billboarded particles you'd hook
        // WorldRenderer via a mixin and render with the 3D projection matrix.
        // This simplified version projects a screen-space approximation so
        // the project compiles and runs stand-alone without extra mixins.
        for (Particle p : particles) {
            double dx = p.x - camPos.x;
            double dy = p.y - camPos.y;
            double dz = p.z - camPos.z;
            double distSq = dx * dx + dy * dy + dz * dz;
            if (distSq > 64 * 64) continue;

            int alpha = p.getAlpha();
            int color = ColorUtil.withAlpha(p.color, alpha);

            int screenX = client.getWindow().getScaledWidth() / 2;
            int screenY = client.getWindow().getScaledHeight() / 2;

            int size = Math.max(1, Math.round(p.size * 20));
            context.fill(screenX - size / 2, screenY - size / 2, screenX + size / 2, screenY + size / 2, color);
        }
    }

    public int getActiveCount() {
        return particles.size();
    }
}
