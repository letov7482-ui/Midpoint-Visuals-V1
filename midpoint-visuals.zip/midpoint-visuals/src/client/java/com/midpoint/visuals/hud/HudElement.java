package com.midpoint.visuals.hud;

import com.midpoint.visuals.animation.AnimatedValue;
import com.midpoint.visuals.animation.Easing;
import net.minecraft.client.gui.DrawContext;

/**
 * Base class for every draggable HUD widget (Watermark, FPS, Coordinates,
 * ...). Handles position, enabled state and the fade-in animation; subclasses
 * only implement their own content in {@link #renderContent}.
 */
public abstract class HudElement {

    private final String name;
    protected float x, y;
    protected float width = 100f, height = 20f;
    private boolean enabled = true;

    protected final AnimatedValue fade = new AnimatedValue(1f, Easing.CUBIC_OUT, 250);

    protected HudElement(String name, float defaultX, float defaultY) {
        this.name = name;
        this.x = defaultX;
        this.y = defaultY;
    }

    /** Subclasses draw their actual widget content here, at (x, y). */
    protected abstract void renderContent(DrawContext context, float deltaTime);

    public final void render(DrawContext context, float deltaTime) {
        if (!enabled && fade.get() <= 0.01f) return;
        renderContent(context, deltaTime);
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
        fade.animateTo(enabled ? 1f : 0f);
    }

    public boolean isEnabled() {
        return enabled;
    }

    public String getName() {
        return name;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }

    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public boolean isHovered(double mouseX, double mouseY) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }
}
