package com.midpoint.visuals.render;

import net.minecraft.client.gui.DrawContext;

/**
 * Fakes a soft drop-shadow behind panels by stacking several rounded rects
 * with decreasing alpha. Cheap enough to run every frame on low-end/Android
 * devices, unlike a real gaussian blur pass.
 */
public final class ShadowRenderer {

    private ShadowRenderer() {
    }

    private static final int LAYERS = 6;

    public static void drawShadow(DrawContext context, float x, float y, float width, float height, float radius, int spread, int baseAlpha) {
        for (int i = LAYERS; i > 0; i--) {
            float grow = (spread / (float) LAYERS) * i;
            int alpha = (int) (baseAlpha * (1f - (i / (float) (LAYERS + 1))) / LAYERS);

            RoundedRenderer.drawRoundedRect(
                    context,
                    x - grow, y - grow,
                    width + grow * 2, height + grow * 2,
                    radius + grow,
                    ColorUtil.rgba(0, 0, 0, Math.max(1, alpha))
            );
        }
    }
}
