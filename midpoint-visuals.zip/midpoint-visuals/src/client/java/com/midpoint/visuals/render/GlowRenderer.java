package com.midpoint.visuals.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.DrawContext;

/**
 * Draws a glowing halo around a rectangle by layering additive, expanding,
 * fading copies of the shape. Used by Target ESP rings, China Hat and hover
 * states in the ClickGUI.
 */
public final class GlowRenderer {

    private GlowRenderer() {
    }

    public static void drawGlow(DrawContext context, float x, float y, float width, float height, float radius, int color, int intensity) {
        RenderSystem.enableBlend();
        RenderSystem.blendFuncSeparate(
                com.mojang.blaze3d.platform.GlStateManager.SrcFactor.SRC_ALPHA,
                com.mojang.blaze3d.platform.GlStateManager.DstFactor.ONE,
                com.mojang.blaze3d.platform.GlStateManager.SrcFactor.ONE,
                com.mojang.blaze3d.platform.GlStateManager.DstFactor.ZERO
        );

        int layers = 4;
        for (int i = layers; i > 0; i--) {
            float grow = i * 1.5f;
            int alpha = Math.max(1, (intensity / layers) * (layers - i + 1) / layers);
            RoundedRenderer.drawRoundedRect(
                    context,
                    x - grow, y - grow, width + grow * 2, height + grow * 2,
                    radius + grow,
                    ColorUtil.withAlpha(color, alpha)
            );
        }

        RenderSystem.defaultBlendFunc();
    }
}
