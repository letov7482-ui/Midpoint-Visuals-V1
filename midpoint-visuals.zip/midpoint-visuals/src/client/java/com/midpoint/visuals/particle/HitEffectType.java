package com.midpoint.visuals.particle;

import com.midpoint.visuals.render.ColorUtil;

public enum HitEffectType {
    STARS(ColorUtil.rgba(255, 255, 255, 255)),
    BLUE_ENERGY(ColorUtil.BRAND_BLUE),
    FIRE(ColorUtil.rgba(255, 140, 40, 255)),
    SNOW(ColorUtil.rgba(220, 235, 255, 255)),
    CRYSTAL(ColorUtil.rgba(120, 200, 255, 255)),
    MAGIC(ColorUtil.rgba(180, 100, 255, 255));

    public final int color;

    HitEffectType(int color) {
        this.color = color;
    }
}
