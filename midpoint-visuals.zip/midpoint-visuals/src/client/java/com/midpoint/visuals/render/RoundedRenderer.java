package com.midpoint.visuals.render;

import net.minecraft.client.gui.DrawContext;

/**
 * Draws rounded rectangles by approximating the corners with small triangular
 * steps. Every Midpoint panel (watermark, HUD elements, ClickGUI windows)
 * goes through this renderer so the rounding radius stays consistent across
 * the whole client.
 */
public final class RoundedRenderer {

    private RoundedRenderer() {
    }

    /** Default corner radius used everywhere in Midpoint's UI. */
    public static final int DEFAULT_RADIUS = 6;

    public static void drawRoundedRect(DrawContext context, float x, float y, float width, float height, float radius, int color) {
        radius = Math.min(radius, Math.min(width, height) / 2f);

        int x0 = Math.round(x);
        int y0 = Math.round(y);
        int x1 = Math.round(x + width);
        int y1 = Math.round(y + height);
        int r = Math.round(radius);

        // Center cross (avoids double corner overdraw)
        context.fill(x0 + r, y0, x1 - r, y1, color);
        context.fill(x0, y0 + r, x0 + r, y1 - r, color);
        context.fill(x1 - r, y0 + r, x1, y1 - r, color);

        drawCorner(context, x0 + r, y0 + r, r, color, 180, 270);
        drawCorner(context, x1 - r, y0 + r, r, color, 270, 360);
        drawCorner(context, x0 + r, y1 - r, r, color, 90, 180);
        drawCorner(context, x1 - r, y1 - r, r, color, 0, 90);
    }

    /** Rounded rect with only the top or bottom corners rounded (headers, tabs). */
    public static void drawRoundedRectTop(DrawContext context, float x, float y, float width, float height, float radius, int color) {
        int x0 = Math.round(x), y0 = Math.round(y), x1 = Math.round(x + width), y1 = Math.round(y + height);
        int r = Math.round(radius);

        context.fill(x0, y0 + r, x1, y1, color);
        context.fill(x0 + r, y0, x1 - r, y0 + r, color);

        drawCorner(context, x0 + r, y0 + r, r, color, 180, 270);
        drawCorner(context, x1 - r, y0 + r, r, color, 270, 360);
    }

    private static void drawCorner(DrawContext context, int cx, int cy, int radius, int color, int fromDeg, int toDeg) {
        if (radius <= 0) return;

        // Fine-grained scanline approximation of a quarter circle.
        for (int dy = 0; dy <= radius; dy++) {
            double frac = dy / (double) radius;
            int dx = (int) Math.round(Math.sqrt(Math.max(0, radius * radius - dy * dy)));

            boolean topHalf = fromDeg == 180 || fromDeg == 270;
            boolean leftHalf = fromDeg == 90 || fromDeg == 180;

            int py = topHalf ? cy - dy : cy + dy;
            int startX = leftHalf ? cx - radius : cx;
            int endX = leftHalf ? cx : cx + radius;
            int cutX = leftHalf ? cx - dx : cx + dx;

            if (leftHalf) {
                context.fill(cutX, py, endX, py + 1, color);
            } else {
                context.fill(startX, py, cutX, py + 1, color);
            }
        }
    }
}
