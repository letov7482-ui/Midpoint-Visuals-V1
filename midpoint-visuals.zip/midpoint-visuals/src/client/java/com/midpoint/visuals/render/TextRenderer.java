package com.midpoint.visuals.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/**
 * Thin wrapper around vanilla's font renderer so every piece of text in
 * Midpoint Visuals shares the same shadow/color/scale conventions instead of
 * every module calling drawContext.drawText with slightly different args.
 */
public final class TextRenderer {

    private TextRenderer() {
    }

    public static void draw(DrawContext context, String text, float x, float y, int color, boolean shadow) {
        var font = MinecraftClient.getInstance().textRenderer;
        context.getMatrices().pushMatrix();
        context.drawText(font, Text.literal(text), Math.round(x), Math.round(y), color, shadow);
        context.getMatrices().popMatrix();
    }

    public static void drawScaled(DrawContext context, String text, float x, float y, float scale, int color, boolean shadow) {
        var font = MinecraftClient.getInstance().textRenderer;
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x, y);
        context.getMatrices().scale(scale, scale);
        context.drawText(font, Text.literal(text), 0, 0, color, shadow);
        context.getMatrices().popMatrix();
    }

    public static int width(String text) {
        return MinecraftClient.getInstance().textRenderer.getWidth(text);
    }

    public static int lineHeight() {
        return MinecraftClient.getInstance().textRenderer.fontHeight;
    }
}
