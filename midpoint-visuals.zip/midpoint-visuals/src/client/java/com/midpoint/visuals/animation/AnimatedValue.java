package com.midpoint.visuals.animation;

/**
 * A single animated float value (opacity, width, offset, whatever). Every
 * ClickGUI panel, HUD drag animation and toggle switch in Midpoint Visuals
 * is backed by one of these instead of hand-rolled lerp code.
 * <p>
 * Usage:
 * <pre>
 *   AnimatedValue alpha = new AnimatedValue(0f, Easing.CUBIC_OUT, 250);
 *   alpha.animateTo(1f);
 *   // each frame:
 *   float current = alpha.get();
 * </pre>
 */
public final class AnimatedValue {

    private final Easing easing;
    private final long durationMs;

    private float start;
    private float target;
    private long startTime;

    public AnimatedValue(float initial, Easing easing, long durationMs) {
        this.start = initial;
        this.target = initial;
        this.easing = easing;
        this.durationMs = durationMs;
        this.startTime = System.currentTimeMillis();
    }

    public void animateTo(float newTarget) {
        if (Float.compare(newTarget, target) == 0) return;
        this.start = get();
        this.target = newTarget;
        this.startTime = System.currentTimeMillis();
    }

    public float get() {
        long elapsed = System.currentTimeMillis() - startTime;
        if (elapsed >= durationMs) return target;

        float t = elapsed / (float) durationMs;
        float eased = easing.apply(t);
        return start + (target - start) * eased;
    }

    public boolean isFinished() {
        return System.currentTimeMillis() - startTime >= durationMs;
    }

    public float getTarget() {
        return target;
    }
}
