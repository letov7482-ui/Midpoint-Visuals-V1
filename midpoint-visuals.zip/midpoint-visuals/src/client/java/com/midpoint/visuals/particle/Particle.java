package com.midpoint.visuals.particle;

/**
 * A single, cheap, world-space particle. Position is kept in doubles
 * (matches Minecraft's world coordinates) while everything else stays in
 * float for speed. No allocations happen after spawn - velocity/size/alpha
 * are mutated in place every tick by {@link ParticleEngine}.
 */
public final class Particle {

    public double x, y, z;
    public float velX, velY, velZ;
    public float size;
    public float rotation;
    public float rotationSpeed;
    public int color;
    public int maxLifeTicks;
    public int lifeTicks;

    public Particle(double x, double y, double z, float velX, float velY, float velZ, float size, int color, int maxLifeTicks) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.velX = velX;
        this.velY = velY;
        this.velZ = velZ;
        this.size = size;
        this.color = color;
        this.maxLifeTicks = maxLifeTicks;
        this.lifeTicks = 0;
        this.rotation = (float) (Math.random() * 360);
        this.rotationSpeed = (float) (Math.random() * 10 - 5);
    }

    public boolean isDead() {
        return lifeTicks >= maxLifeTicks;
    }

    public float getLifeRatio() {
        return lifeTicks / (float) maxLifeTicks;
    }

    /** Alpha fades out smoothly over the last 40% of the particle's life. */
    public int getAlpha() {
        float ratio = getLifeRatio();
        float fadeStart = 0.6f;
        if (ratio < fadeStart) return 255;
        float fadeT = (ratio - fadeStart) / (1 - fadeStart);
        return Math.round(255 * (1 - fadeT));
    }
}
