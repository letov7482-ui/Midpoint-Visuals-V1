package com.midpoint.visuals.module;

import com.midpoint.visuals.animation.AnimatedValue;
import com.midpoint.visuals.animation.Easing;

/**
 * Base class for every toggleable feature in Midpoint Visuals. Handles the
 * common bits (name, category, enabled state, smooth enable/disable fade)
 * so individual modules only implement their own render/tick logic.
 */
public abstract class Module {

    private final String name;
    private final ModuleCategory category;
    private boolean enabled;

    /** 0 = fully off, 1 = fully on. Lets modules fade their effect in/out instead of popping. */
    protected final AnimatedValue enableProgress = new AnimatedValue(0f, Easing.CUBIC_OUT, 300);

    protected Module(String name, ModuleCategory category) {
        this(name, category, false);
    }

    protected Module(String name, ModuleCategory category, boolean enabledByDefault) {
        this.name = name;
        this.category = category;
        setEnabled(enabledByDefault, true);
    }

    public void toggle() {
        setEnabled(!enabled, false);
    }

    public void setEnabled(boolean enabled, boolean instant) {
        this.enabled = enabled;
        enableProgress.animateTo(enabled ? 1f : 0f);
        if (instant) {
            // Snap immediately, used only on load so the game doesn't fade in every module at startup.
            enableProgress.animateTo(enabled ? 1f : 0f);
        }
        if (enabled) onEnable(); else onDisable();
    }

    protected void onEnable() {
    }

    protected void onDisable() {
    }

    /** Called once per client tick while the module (or its fade-out) is still active. */
    public void tick() {
    }

    public String getName() {
        return name;
    }

    public ModuleCategory getCategory() {
        return category;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public float getFade() {
        return enableProgress.get();
    }
}
