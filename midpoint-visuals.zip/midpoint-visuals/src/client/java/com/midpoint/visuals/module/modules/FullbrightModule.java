package com.midpoint.visuals.module.modules;

import com.midpoint.visuals.module.Module;
import com.midpoint.visuals.module.ModuleCategory;
import net.minecraft.client.MinecraftClient;

/**
 * Overrides the gamma option while enabled, restoring the player's original
 * value on disable. This is the same effect as manually maxing out the
 * brightness slider - purely cosmetic, no unfair information advantage.
 */
public final class FullbrightModule extends Module {

    private double previousGamma;

    public FullbrightModule() {
        super("Fullbright", ModuleCategory.VISUAL);
    }

    @Override
    protected void onEnable() {
        var options = MinecraftClient.getInstance().options;
        previousGamma = options.getGamma().getValue();
        options.getGamma().setValue(15.0);
    }

    @Override
    protected void onDisable() {
        MinecraftClient.getInstance().options.getGamma().setValue(previousGamma);
    }
}
