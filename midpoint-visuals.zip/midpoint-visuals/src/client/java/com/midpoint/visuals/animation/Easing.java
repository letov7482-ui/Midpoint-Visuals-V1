package com.midpoint.visuals.animation;

/**
 * Standard easing curves. Every value takes t in [0,1] and returns the eased
 * progress, also generally in [0,1] (Elastic/Back/Bounce may briefly overshoot,
 * which is intended - that's what gives them their "snap").
 */
public enum Easing {
    LINEAR {
        public float apply(float t) { return t; }
    },
    SINE_IN_OUT {
        public float apply(float t) { return (float) (-(Math.cos(Math.PI * t) - 1) / 2); }
    },
    QUAD_IN_OUT {
        public float apply(float t) { return t < 0.5f ? 2 * t * t : 1 - (float) Math.pow(-2 * t + 2, 2) / 2; }
    },
    CUBIC_IN {
        public float apply(float t) { return t * t * t; }
    },
    CUBIC_OUT {
        public float apply(float t) { return 1 - (float) Math.pow(1 - t, 3); }
    },
    CUBIC_IN_OUT {
        public float apply(float t) { return t < 0.5f ? 4 * t * t * t : 1 - (float) Math.pow(-2 * t + 2, 3) / 2; }
    },
    EXPO_OUT {
        public float apply(float t) { return t >= 1f ? 1f : 1 - (float) Math.pow(2, -10 * t); }
    },
    EXPO_IN {
        public float apply(float t) { return t <= 0f ? 0f : (float) Math.pow(2, 10 * t - 10); }
    },
    BACK_OUT {
        public float apply(float t) {
            float c1 = 1.70158f, c3 = c1 + 1;
            return 1 + c3 * (float) Math.pow(t - 1, 3) + c1 * (float) Math.pow(t - 1, 2);
        }
    },
    ELASTIC_OUT {
        public float apply(float t) {
            if (t == 0f || t == 1f) return t;
            float c4 = (float) (2 * Math.PI / 3);
            return (float) (Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * c4) + 1);
        }
    },
    BOUNCE_OUT {
        public float apply(float t) {
            float n1 = 7.5625f, d1 = 2.75f;
            if (t < 1 / d1) return n1 * t * t;
            if (t < 2 / d1) return n1 * (t -= 1.5f / d1) * t + 0.75f;
            if (t < 2.5 / d1) return n1 * (t -= 2.25f / d1) * t + 0.9375f;
            return n1 * (t -= 2.625f / d1) * t + 0.984375f;
        }
    };

    public abstract float apply(float t);
}
