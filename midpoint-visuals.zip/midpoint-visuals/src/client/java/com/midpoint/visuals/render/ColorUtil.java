package com.midpoint.visuals.render;

/**
 * Central place for every color operation used by the render engine.
 * Keeping this logic in one class avoids duplicating ARGB math everywhere.
 */
public final class ColorUtil {

    /** Midpoint's signature brand color - bright saturated blue. */
    public static final int BRAND_BLUE = rgba(46, 108, 255, 255);
    public static final int BRAND_BLUE_LIGHT = rgba(112, 170, 255, 255);
    public static final int PANEL_BLACK = rgba(12, 14, 18, 190);
    public static final int PANEL_GRAY = rgba(28, 30, 36, 220);

    private ColorUtil() {
    }

    public static int rgba(int r, int g, int b, int a) {
        return (clamp(a) << 24) | (clamp(r) << 16) | (clamp(g) << 8) | clamp(b);
    }

    public static int withAlpha(int argb, int alpha) {
        return (clamp(alpha) << 24) | (argb & 0x00FFFFFF);
    }

    public static int alphaOf(int argb) {
        return (argb >> 24) & 0xFF;
    }

    /** Linearly interpolates between two ARGB colors, t in [0, 1]. */
    public static int lerp(int from, int to, float t) {
        t = clamp01(t);

        int fa = (from >> 24) & 0xFF, fr = (from >> 16) & 0xFF, fg = (from >> 8) & 0xFF, fb = from & 0xFF;
        int ta = (to >> 24) & 0xFF, tr = (to >> 16) & 0xFF, tg = (to >> 8) & 0xFF, tb = to & 0xFF;

        int a = (int) (fa + (ta - fa) * t);
        int r = (int) (fr + (tr - fr) * t);
        int g = (int) (fg + (tg - fg) * t);
        int b = (int) (fb + (tb - fb) * t);

        return rgba(r, g, b, a);
    }

    /** Builds a smooth rainbow color from a phase in [0, 1]. */
    public static int rainbow(float phase, int alpha) {
        phase = phase - (float) Math.floor(phase);
        float hue = phase * 360f;
        float[] rgb = hsvToRgb(hue, 0.85f, 1.0f);
        return rgba((int) (rgb[0] * 255), (int) (rgb[1] * 255), (int) (rgb[2] * 255), alpha);
    }

    /** Color that shifts from brand-blue to white based on distance ratio (0 = close, 1 = far). */
    public static int byDistance(float ratio) {
        return lerp(BRAND_BLUE_LIGHT, rgba(255, 255, 255, 255), clamp01(ratio));
    }

    private static float[] hsvToRgb(float h, float s, float v) {
        int i = (int) (h / 60f) % 6;
        float f = (h / 60f) - i;
        float p = v * (1 - s);
        float q = v * (1 - f * s);
        float t = v * (1 - (1 - f) * s);

        return switch (i) {
            case 0 -> new float[]{v, t, p};
            case 1 -> new float[]{q, v, p};
            case 2 -> new float[]{p, v, t};
            case 3 -> new float[]{p, q, v};
            case 4 -> new float[]{t, p, v};
            default -> new float[]{v, p, q};
        };
    }

    private static int clamp(int v) {
        return Math.max(0, Math.min(255, v));
    }

    private static float clamp01(float v) {
        return Math.max(0f, Math.min(1f, v));
    }
}
