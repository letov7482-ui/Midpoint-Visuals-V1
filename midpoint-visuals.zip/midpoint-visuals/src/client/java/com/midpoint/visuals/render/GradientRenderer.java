package com.midpoint.visuals.render;

import net.minecraft.client.gui.DrawContext;

/**
 * Draws linear gradients. Used for the watermark top-bar, ClickGUI headers,
 * Tracers, China Hat and every other "brand blue fading to transparent"
 * effect in the client.
 */
public final class GradientRenderer {

    private GradientRenderer() {
    }

    public static void horizontal(DrawContext context, int x, int y, int width, int height, int colorLeft, int colorRight) {
        context.fillGradient(x, y, x + width, y + height, colorLeft, colorRight);
    }

    public static void vertical(DrawContext context, int x, int y, int width, int height, int colorTop, int colorBottom) {
        // fillGradient interpolates top->bottom when the rect is taller than wide,
        // but we make the direction explicit by pre-blending manually for consistency.
        int steps = Math.max(1, height);
        for (int i = 0; i < steps; i++) {
            float t = i / (float) steps;
            int color = ColorUtil.lerp(colorTop, colorBottom, t);
            context.fill(x, y + i, x + width, y + i + 1, color);
        }
    }

    /** A thin accent line, e.g. the signature blue strip on top of the watermark. */
    public static void accentBar(DrawContext context, int x, int y, int width, int thickness) {
        horizontal(context, x, y, width, thickness, ColorUtil.BRAND_BLUE, ColorUtil.BRAND_BLUE_LIGHT);
    }
}
